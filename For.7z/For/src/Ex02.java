import java.util.Scanner;
public class Ex02 {

	public static void main(String[] args) {
		Scanner dado= new Scanner (System.in);
		int x = 0, y = 0, i , j=0,idade,qtdeidade = 0,qtde = 0;
				double peso,altura,media = 0;
				System.out.println ("Digite o valor de X");
				x = dado.nextInt();
				for (i=1; i<=x; i++) {
					System.out.println ("Digite o valor de y");
						y = dado.nextInt();
						for(j=1;j<=y;j++) {
							System.out.println ("Digite a idade do jogador" + j);
							idade = dado.nextInt();
							System.out.println ("Digite o peso do jogador");
							peso = dado.nextDouble();
							System.out.println("Digite a altura do jogador");
							altura = dado.nextDouble();
							media = qtdeidade/y;
							if(idade<18) {
								qtde = qtde +1;
					
							}
						}
				}
				

	}

}
