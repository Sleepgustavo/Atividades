
public class atividade05 {
	
	public static float inputFlo(String text);
	Scanner sc = new Scanner(System.in);
	float value = sc.nextFloat();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
